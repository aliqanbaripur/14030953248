
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# تولید داده مصنوعی
np.random.seed(0)
names = ["Ali", "Zahra", "Mohammad", "Sara", "Reza", "Fatemeh", "Mehdi", "Negar", "Amin", "Rana"]
genders = ["Male", "Female"]
fields = ["Engineering", "Medical", "Arts", "Humanities"]
cities = ["Tehran", "Shiraz", "Isfahan", "Tabriz", "Mashhad"]
diseases = ["None", "Diabetes", "Hypertension", "Asthma"]
phenomena = ["A", "B", "C"]

data = []
for i in range(100):
    row = {
        "ID": i+1,
        "Name": np.random.choice(names),
        "Gender": np.random.choice(genders),
        "Field": np.random.choice(fields),
        "City": np.random.choice(cities),
        "Disease": np.random.choice(diseases),
        "Age": np.random.randint(18, 60),
        "Height": np.random.randint(150, 200),
        "Weight": np.random.randint(50, 100),
        "SleepHours": np.random.randint(4, 10),
        "StudyHours": np.random.randint(0, 6),
        "ExerciseHours": np.random.randint(0, 5),
        "Smoking": np.random.choice([0, 1]),
        "HealthyDiet": np.random.choice([0, 1]),
        "StressLevel": np.random.randint(1, 10),
        "PhoneUsageHours": np.random.randint(1, 10),
        "Phenomenon": np.random.choice(phenomena)
    }
    data.append(row)

df = pd.DataFrame(data)

# ذخیره داده‌ها
df.to_csv("phenomenon_dataset.csv", index=False, encoding='utf-8-sig')
df.to_excel("phenomenon_dataset.xlsx", index=False)

# پیش‌پردازش
df_processed = df.copy()
label_cols = ["Name", "Gender", "Field", "City", "Disease", "Phenomenon"]
encoders = {}

for col in label_cols:
    le = LabelEncoder()
    df_processed[col] = le.fit_transform(df_processed[col])
    encoders[col] = le

features = df_processed.drop(columns=["ID", "Phenomenon"])
labels = df_processed["Phenomenon"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(features)

# KMeans
kmeans = KMeans(n_clusters=3, random_state=0)
kmeans_labels = kmeans.fit_predict(X_scaled)

# KNN
X_train, X_test, y_train, y_test = train_test_split(X_scaled, labels, test_size=0.2, random_state=42)
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)
report = classification_report(y_test, y_pred, target_names=encoders["Phenomenon"].classes_)

# ذخیره گزارش
with open("knn_classification_report.txt", "w") as f:
    f.write("KNN Classification Report\n")
    f.write(report)

# کاهش ابعاد و رسم نمودار
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

plt.figure(figsize=(8, 6))
sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1], hue=kmeans_labels, palette='Set2', s=60)
plt.title("KMeans Clustering with PCA")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.legend(title="Cluster")
plt.tight_layout()
plt.savefig("kmeans_clustering_plot.png")
plt.close()
